TARTAY 2D Android WebView project
WebView URL: https://tartay-2d.yehtetaung7655.workers.dev/
App name: တာတေ 2D
