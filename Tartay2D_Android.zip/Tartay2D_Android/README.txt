TARTAY 2D Android WebView project v1.2
WebView URL: https://tartay-2d.yehtetaung7655.workers.dev/
Changes: restored the Android System WebView default User-Agent; retained safe status-bar layout; no SSL bypasses.
